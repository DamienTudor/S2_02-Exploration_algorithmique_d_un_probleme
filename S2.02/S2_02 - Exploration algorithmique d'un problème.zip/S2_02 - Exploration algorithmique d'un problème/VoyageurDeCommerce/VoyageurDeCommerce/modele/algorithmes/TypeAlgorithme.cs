﻿namespace VoyageurDeCommerce.modele.algorithmes
{
    /// <summary> Enumération des algorithmes </summary>
    public enum TypeAlgorithme
    {
        ALGOEXEMPLE,
        CROISSANT
    }
}

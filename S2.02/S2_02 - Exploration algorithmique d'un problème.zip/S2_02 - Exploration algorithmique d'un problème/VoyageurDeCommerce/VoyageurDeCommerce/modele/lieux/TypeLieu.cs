﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoyageurDeCommerce.modele.lieux
{
    /// <summary>Enumération des différents types de lieu</summary>
    public enum TypeLieu
    {
        MAGASIN,USINE
    }
}
